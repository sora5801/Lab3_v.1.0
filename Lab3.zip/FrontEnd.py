from BackEnd import BackEnd
from matplotlib import pyplot as plt
class FrontEnd:
    def __init__(self):
        self.B = BackEnd()
        self.B.LinearRegression()




